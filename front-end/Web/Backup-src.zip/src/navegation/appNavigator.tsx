import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import LandingPage from "../view/screens/landingScreen";
import LoginScreen from "../view/screens/loginScreen";
import SignupScreen from "../view/screens/signupScreen";
import DashboardScreen from "../view/screens/dashboardScreen";

const Stack = createNativeStackNavigator();

export default function AppNavigator() {

    return (
        <Stack.Navigator
            screenOptions={{
                headerShown: false,
            }}
        >
            <Stack.Screen
                name="FaceAttendEDU"
                component={LandingPage}
            />

            <Stack.Screen
                name="FaceAttendEDU-Login"
                component={LoginScreen}
            />

            <Stack.Screen
                name="FaceAttendEDU-Register"
                component={SignupScreen}
            />

            <Stack.Screen
                name="FaceAttendEDU-Dashboard"
                component={DashboardScreen}
            />
        </Stack.Navigator>
    );
}